#include <stdio.h>
#include <signal.h>

void handle(int sig)
{
	printf(" Ctrl+c\n");
}

int main()
{
	struct sigaction act;
	act.sa_handler = handle;
	act.sa_flags = 0;
	sigemptyset(&act.sa_mask);
	sigaction(SIGINT,&act,NULL);
	while(1)
	{
		;
	}
}
