#include <iostream>
#include <fstream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <stdlib.h>
#include <vector>
#include <unistd.h>
#include <sys/stat.h>

#define handle_error(msg) do{ \
    std::cerr << msg <<std::endl; \
    exit(1); \
}while(0)

const std::string &filename ="hello.txt";

std::string load_file_content(const std::string&filename)
{
 //预加载文件内容
	std::ifstream file(filename);
	std::string content;
	if(file)
	{
		// 读取文件内容到字符串
		std::string line;
		std::vector<std::string> lines;
		while (std::getline(file, line)) {
			 content += line + "\n";
		}
		file.close();  // 关闭文件
	}
	else
	{
		handle_error("无法打开文件");
	}
	return content;
}


int main (int argc, char *argv[])
{
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " <IP> <Port>" << std::endl;
        return 1;
    }
    
    
    int server_fd = socket(AF_INET, SOCK_STREAM,0); 
    if(server_fd < 0)
    {
        handle_error("socket");
    }
    
    struct sockaddr_in server_addr;
    struct sockaddr_in conn_addr;
    socklen_t conn_size = (socklen_t)sizeof(conn_addr);
    
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(atoi(argv[2]));//htons(PORT);
    if ( inet_aton(argv[1], &server_addr.sin_addr)==0)
    {
        handle_error("inet_aton");
        return -1;
    } 
    if(bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)))
    {
        handle_error("connect error");
    }
    if (listen(server_fd, 10) < 0) {
        handle_error("listen error");
    }
   	
   	std::string file_content = load_file_content(filename);
    struct stat file_stat;
    time_t last_mod_time = 0;

    if (stat(filename.c_str(), &file_stat) == 0) {
        last_mod_time = file_stat.st_mtime;  // 获取文件的最后修改时间
    } else {
        std::cerr << "无法获取文件信息" << std::endl;
        return 1;
    }
    
	
    while(1)
    {
		int conn_fd = accept(server_fd, (struct sockaddr*)&conn_addr, &conn_size);
		if(conn_fd == -1)
		{
			handle_error("accept");
		}
		//没有变化发送1次
		if(!file_content.empty())
		{
			int len = send(conn_fd, file_content.c_str(), file_content.size(), 0);
			if(len<=0)
			{
				std::cerr << "Client disconnected or send error" 
					 	  << std::endl;
					 	  close(conn_fd);//关闭客户端连接
			}
			else
			{
			 	std::cout << "Sent " << len 
			 			  << " bytes to the server." << std::endl;   
			}
			//file_content.clear();//清除缓冲区
		}
		sleep(1); //模拟处理延时
		
        //处理客户端连接
		while(1)
		{
			 // 检查文件是否有变化
            if (stat(filename.c_str(), &file_stat) == 0) {
                if (file_stat.st_mtime != last_mod_time) {
                    file_content.clear();//清除缓冲区
                    last_mod_time = file_stat.st_mtime;
                    file_content = load_file_content(filename);
                    
                    std::cout << "File content updated." << std::endl;
                    
					if(!file_content.empty())
					{
						int len = send(conn_fd, file_content.c_str(), file_content.size(), 0);
						if(len<=0)
						{
							std::cerr << "Client disconnected or send error" 
								 	  << std::endl;
							break;
						}
						else
						{
						 	std::cout << "Sent " << len 
						 			  << " bytes to the server." << std::endl;   
						}
						
					}
					sleep(1); //模拟处理延时
                }
                
            } 
            else 
            {
                std::cerr << "无法获取文件信息" << std::endl;
                break;
            }
	
		}
		close(conn_fd);//关闭客户端连接
    }
	
	close(server_fd); //关闭socket
	return 0;
}
