#ifndef _CLIENT_BASE_H_
#define _CLIENT_BASE_H_

bool login_input(void);

#endif
