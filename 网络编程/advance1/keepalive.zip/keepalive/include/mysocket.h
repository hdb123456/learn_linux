#ifndef MYSOCKET_H
#define MYSOCKET_H

#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif



#ifdef __cplusplus
extern int sfd;
#include <vector>
#include <sys/socket.h>
struct SockOptParam {
    int level;
    int optname;
    const void* optval;
    socklen_t optlen;
};

class my_socket{
	public:
	static void create_socket(void);
	static int bind_socket(char *argv[]);
	static void listen_socket(void);
    static void keepalive(int sockfd, const std::vector<SockOptParam>& params);
};

void arg_check(int argc, char *argv[]);
void get_peer(int fd);
#endif

#endif
