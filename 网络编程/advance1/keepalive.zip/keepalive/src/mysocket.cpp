#include "mysocket.h"
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <vector>

#define LISTEN_NUM 5
#define handle_error(msg)                                                              \
    do                                                                         \
    {                                                                          \
        std::cout << msg << std::endl;                                         \
        exit(1);                                                               \
    } while (0)



void arg_check(int argc, char *argv[])
{
    if (argc != 3)
    {
        handle_error("Usage: ./client <server_ip> <server_port>");
        exit(1);
    }
}

void my_socket::create_socket(void)
{
	int on=1;
    sfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sfd < 0)
    {
        handle_error("Error creating socket");
        exit(1);
    }
    /*地址快速重用*/
	if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on))==-1)
	{
		perror("setsockopt");
	}
	std::cout<<"create socket..."<<std::endl;
}
int my_socket::bind_socket(char *argv[])
{
    struct sockaddr_in saddr;
    memset(&saddr, 0, sizeof(saddr));
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(atoi(argv[2]));
    saddr.sin_addr.s_addr = inet_addr(argv[1]);
    std::cout<<"bind_socket..."<<std::endl;
    if (bind(sfd, (struct sockaddr *)&saddr, (socklen_t)sizeof(struct sockaddr_in)) < 0)
    {
        handle_error("Error binding socket");
        exit(1);
    }
    return sfd;
}
void my_socket::listen_socket(void)
{
    if(listen(sfd, LISTEN_NUM) == -1)
    {
        handle_error("Error listening");
    }
    std::cout<<"listen_socket..."<<std::endl;
}
//从文件描述符中获取客户端信息
void get_peer(int fd)
{
	struct sockaddr_in addr;
	socklen_t size = sizeof(addr);
	getpeername(fd, (struct sockaddr*)&addr, &size);
	std::cout << "fd:" <<fd
			  << ", ip:"<< inet_ntoa(addr.sin_addr) 
			  << ", PORT: " << ntohs(addr.sin_port) << std::endl;
}
//要求开始首次KeepAlive探测前的TCP空闭时间为3秒，两次KeepAlive探测间的时间间隔为3次，判定断开前的KeepAlive探测次数为7次
void my_socket::keepalive(int sockfd, const std::vector<SockOptParam>& params)
{
    for (const auto& param : params)
    {
        if (setsockopt(sockfd, param.level, param.optname, param.optval, param.optlen) == -1)
        {
            handle_error("setsockopt");
        }
    }
}

