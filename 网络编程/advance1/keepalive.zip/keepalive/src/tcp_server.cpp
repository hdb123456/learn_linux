#include "tcp_server.h"
#include "mysocket.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <iostream>
#include <sys/epoll.h>
#include <netinet/tcp.h>
int sfd;
#define MAX_EVENTS 10
#define read_len 1024

int main(int argc, char *argv[])
{
    
    struct sockaddr_in client_addr;
    socklen_t client_addrlen = sizeof(client_addr);
    
    char buff[read_len]={0};

    struct epoll_event ev, events[MAX_EVENTS];
    int nfds, epollfd;

/* Code to set up listening socket, 'listen_sock',
              (socket(), bind(), listen()) omitted. */
    arg_check(argc, argv);
    my_socket::create_socket();
    sfd = my_socket::bind_socket(argv);
    my_socket::listen_socket();
    
    //initial epoll
    epollfd = epoll_create(1);
    if (epollfd == -1) 
    {
        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }
    ev.events = EPOLLIN;
    ev.data.fd = sfd;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, sfd, &ev) == -1) {
        perror("epoll_ctl: listen_sfd");
        exit(EXIT_FAILURE);
    }
    std::cout<<"waiting for client..."<<std::endl;
    
    while(true){
         nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);//客户端连接上服务端或连接上后发送数据均会触发
         if (nfds == -1) {
             perror("epoll_wait");
             exit(EXIT_FAILURE);
         }
         for(int i=0; i<nfds; i++){
            if(events[i].data.fd == sfd){
               int conn_sock = accept(sfd, (struct sockaddr*)&client_addr, &client_addrlen);
                if(conn_sock == -1)
                {
                    perror("accept");
                    exit(EXIT_FAILURE);  
                }
                get_peer(conn_sock);
                std::cout << "connected" << std::endl;
                puts("");
                ev.events = EPOLLIN;
                ev.data.fd = conn_sock;
                
                if(epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_sock, &ev) == -1)
                {
                    perror("epoll_ctl:conn_sock");
                    exit(EXIT_FAILURE);
                }
                //设置保活连接
                bool flag = false;
                if(!flag)
                {
                    //要求开始首次KeepAlive探测前的TCP空闭时间为3秒，两次KeepAlive探测间的时间间隔为3次，判定断开前的KeepAlive探测次数为7次
                     int attr_on = 1;
                     int idle_time = 3;
                     int intvl_time = 3;
                     int cnt = 7;
                    std::vector<SockOptParam> params = {
                            {SOL_SOCKET, SO_KEEPALIVE, (const char*)&attr_on, sizeof(attr_on)},
                            {SOL_TCP, TCP_KEEPIDLE, (const char*)&idle_time, sizeof(idle_time)},
                            {SOL_TCP, TCP_KEEPINTVL, (const char*)&intvl_time, sizeof(intvl_time)},
                            {SOL_TCP, TCP_KEEPCNT, (const char*)&cnt, sizeof(cnt)}
                    };
                    my_socket::keepalive(conn_sock, params);
                }
            }
            else //处理客户端数据
            {
                int ret = 0;
                memset(buff, 0, sizeof(buff));
                ret = read(events[i].data.fd, buff, sizeof(buff));
                if(ret<=0)
                {
                    if(epoll_ctl(epollfd, EPOLL_CTL_DEL, events[i].data.fd, NULL) == -1)
                    {
                        std::cerr<<"events["<<i<<"].data.fd"<<std::endl;
                        exit(EXIT_FAILURE);
                    }
                    close(events[i].data.fd);
                    get_peer(events[i].data.fd);
                    std::cout << " closed" << std::endl;
                }
                else{
                    buff[ret]='\0';
                    get_peer(events[i].data.fd);
                    std::cout << "data:"<<buff<<std::endl;
                }
            }
        }
    }
    
    close(sfd);
    close(epollfd);
}

