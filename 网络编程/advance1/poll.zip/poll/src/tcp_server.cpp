#include <iostream>
#include <vector>
#include <poll.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <cstring>
#include "tcp_server.h"

const int PORT = 8080;
const int MAX_CLIENTS = 10;
const int BUFFER_SIZE = 1024;

void handle_client(int client_fd) {
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read = read(client_fd, buffer, BUFFER_SIZE);
    if (bytes_read > 0) {
        buffer[bytes_read] = '\0';
        std::cout << "Received from client: " << buffer << std::endl;
        write(client_fd, buffer, bytes_read);  // Echo back to client
    } else if (bytes_read == 0) {
        std::cout << "Client disconnected." << std::endl;
        close(client_fd);
    } else {
        std::cerr << "Error reading from client." << std::endl;
        close(client_fd);
    }
}

int main() {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        std::cerr << "Socket creation failed." << std::endl;
        return -1;
    }

    sockaddr_in server_addr{};
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_fd, (sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        std::cerr << "Bind failed." << std::endl;
        close(server_fd);
        return -1;
    }

    if (listen(server_fd, MAX_CLIENTS) < 0) {
        std::cerr << "Listen failed." << std::endl;
        close(server_fd);
        return -1;
    }

    std::vector<struct pollfd> poll_fds;
    poll_fds.push_back({server_fd, POLLIN, 0});  // Server socket

    while (true) {
        int poll_count = poll(poll_fds.data(), poll_fds.size(), -1);
        if (poll_count < 0) {
            std::cerr << "Poll error." << std::endl;
            break;
        }

        // Check if server socket is ready to accept new connection
        if (poll_fds[0].revents & POLLIN) {
            sockaddr_in client_addr{};
            socklen_t client_addr_len = sizeof(client_addr);
            int client_fd = accept(server_fd, (sockaddr *)&client_addr, &client_addr_len);
            if (client_fd < 0) {
                std::cerr << "Accept failed." << std::endl;
                continue;
            }

            std::cout << "New client connected." << std::endl;
            poll_fds.push_back({client_fd, POLLIN, 0});
        }

        // Check each client socket for incoming data
        for (size_t i = 1; i < poll_fds.size(); ++i) {
            if (poll_fds[i].revents & POLLIN) {
                handle_client(poll_fds[i].fd);
                // Remove the client fd from poll_fds if closed
                if (poll_fds[i].fd == -1) {
                    poll_fds.erase(poll_fds.begin() + i);
                    --i;
                }
            }
        }
    }

    close(server_fd);
    return 0;
}

