#ifndef MYSOCKET_H
#define MYSOCKET_H

void arg_check(int argc, char *argv[]);
void create_socket(void);
int bind_socket(char *argv[]);
void listen_socket(void);
void get_peer(int fd);

#endif
